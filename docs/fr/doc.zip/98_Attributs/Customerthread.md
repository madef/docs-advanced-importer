 * id_lang:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_contact:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * email:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 254
 * token:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * status:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
