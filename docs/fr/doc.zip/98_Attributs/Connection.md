 * id_guest:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_page:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * ip_address:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * http_referer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_shop_group:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
