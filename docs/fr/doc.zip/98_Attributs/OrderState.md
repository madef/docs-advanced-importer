 * send_email:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * module_name:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * invoice:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * color:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * logable:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipped:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * unremovable:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * delivery:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * hidden:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * paid:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * deleted:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * template:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 64
