 * link:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 128
 * new_window:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 32
