 * id_country:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_zone:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * iso_code:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 7
 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
