 * message:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 1600
 * id_cart:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_employee:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * private:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
