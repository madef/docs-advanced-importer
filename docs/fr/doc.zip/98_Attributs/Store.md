 * id_country:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_state:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 128
  address1:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 128
  address2:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 128
 * postcode:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 12
 * city:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * latitude:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 13
 * longitude:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 13
 * hours:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 254
 * phone:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 16
 * fax:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 16
 * note:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 65000
 * email:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 128
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
