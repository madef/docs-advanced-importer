 * lastname:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * firstname:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * email:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 128
 * id_lang:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * passwd:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * last_passwd_gen:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * optin:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_profile:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * bo_color:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * default_tab:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * bo_theme:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * bo_css:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * bo_width:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * bo_menu:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * stats_date_from:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * stats_date_to:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * stats_compare_from:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * stats_compare_to:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * stats_compare_option:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * preselect_date_range:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * id_last_order:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_last_customer_message:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_last_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
