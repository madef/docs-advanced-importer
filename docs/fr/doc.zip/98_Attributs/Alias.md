 * search:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 255
 * alias:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 255
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
