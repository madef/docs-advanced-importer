 * id_group:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_category:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * reduction:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
