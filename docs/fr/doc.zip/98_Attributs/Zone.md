  * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
