 * id_compare:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined

