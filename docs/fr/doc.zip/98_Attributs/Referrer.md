 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * passwd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * http_referer_regexp:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * request_uri_regexp:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * http_referer_like:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * request_uri_like:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * http_referer_regexp_not:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * request_uri_regexp_not:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * http_referer_like_not:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * request_uri_like_not:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * base_fee:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * percent_fee:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * click_fee:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
