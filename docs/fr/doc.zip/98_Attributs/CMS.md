 * id_cms_category:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * position:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * indexation:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * meta_description:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 255
 * meta_keywords:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 255
 * meta_title:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 128
 * link_rewrite:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 128
 * content:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 3999999999999
