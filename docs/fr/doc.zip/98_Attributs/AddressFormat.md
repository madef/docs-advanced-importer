 * format:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_country:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
