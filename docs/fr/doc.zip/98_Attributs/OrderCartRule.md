 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_cart_rule:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_order_invoice:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * value:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * value_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * free_shipping:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
