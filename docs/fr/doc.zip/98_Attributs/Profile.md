 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 32
