 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * key:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * description:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
