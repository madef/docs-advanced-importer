 * id_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * conversion_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * amount:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_cost:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_cost_amount:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * partial:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
