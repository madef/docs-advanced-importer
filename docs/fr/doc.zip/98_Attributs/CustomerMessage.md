 * id_employee:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_customer_thread:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * ip_address:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 15
 * message:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 65000
 * file_name:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * user_agent:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * private:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * read:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
