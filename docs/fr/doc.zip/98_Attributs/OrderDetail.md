 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_order_invoice:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_warehouse:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * product_id:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_attribute_id:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * product_quantity:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * product_quantity_in_stock:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_quantity_return:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_quantity_refunded:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_quantity_reinjected:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_price:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * reduction_percent:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * reduction_amount:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * reduction_amount_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * reduction_amount_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * group_reduction:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_quantity_discount:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_ean13:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_upc:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_supplier_reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_weight:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * tax_name:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * tax_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * tax_computation_method:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * ecotax:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * ecotax_tax_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * discount_quantity_applied:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * download_hash:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * download_nb:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * download_deadline:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * unit_price_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * unit_price_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_price_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_price_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * purchase_supplier_price:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * original_product_price:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
