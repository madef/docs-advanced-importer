 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * position:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * cover:
    * lang: false
    * shop: true
    * validator: none
    * required: false
    * size: undefined
 * legend:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 128
