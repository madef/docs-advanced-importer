 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_country:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_group:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * from_quantity:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * price:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * reduction:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * reduction_type:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * from:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * to:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
