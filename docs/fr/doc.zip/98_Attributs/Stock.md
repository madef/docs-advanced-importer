 * id_warehouse:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_product_attribute:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * ean13:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * upc:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * physical_quantity:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * usable_quantity:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * price_te:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
