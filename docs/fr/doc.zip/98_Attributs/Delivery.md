 * id_carrier:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_range_price:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_range_weight:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_zone:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_shop_group:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * price:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined

