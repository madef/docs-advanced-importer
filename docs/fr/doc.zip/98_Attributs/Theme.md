 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * directory:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * responsive:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * default_left_column:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * default_right_column:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * product_per_page:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
