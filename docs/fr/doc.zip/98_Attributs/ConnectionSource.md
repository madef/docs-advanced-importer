 * id_connections:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * http_referer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * request_uri:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * keywords:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
