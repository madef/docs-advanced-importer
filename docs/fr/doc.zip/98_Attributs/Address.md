 * id_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_manufacturer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_supplier:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_warehouse:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_country:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_state:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * alias:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * company:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * lastname:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * firstname:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * vat_number:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
  address1:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 128
  address2:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 128
 * postcode:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 12
 * city:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * other:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 300
 * phone:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * phone_mobile:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * dni:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 16
 * deleted:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
