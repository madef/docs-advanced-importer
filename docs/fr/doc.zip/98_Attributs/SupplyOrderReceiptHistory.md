 * id_supply_order_detail:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_supply_order_state:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_employee:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * employee_firstname:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * employee_lastname:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * quantity:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
