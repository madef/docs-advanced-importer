 * id_address_delivery:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_address_invoice:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_cart:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_shop_group:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_lang:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_carrier:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * current_state:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * secure_key:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * payment:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * module:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * recyclable:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * gift:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * gift_message:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * mobile_theme:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_discounts:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_discounts_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_discounts_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_paid:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * total_paid_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_paid_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_paid_real:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * total_products:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * total_products_wt:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * total_shipping:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_shipping_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_shipping_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * carrier_tax_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_wrapping:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_wrapping_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_wrapping_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_number:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * conversion_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * invoice_number:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * delivery_number:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * invoice_date:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * delivery_date:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * valid:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
