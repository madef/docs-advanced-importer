 * delivery_note:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * editable:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * receipt_state:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * pending_receipt:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * enclosed:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * color:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 128
