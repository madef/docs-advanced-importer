 * id_feature:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * custom:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * value:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 255
