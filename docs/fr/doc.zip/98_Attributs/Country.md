 * id_zone:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * call_prefix:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * iso_code:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 3
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * contains_states:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * need_identification_number:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * need_zip_code:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * zip_code_format:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * display_tax_label:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 64
