 * location:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_product_attribute:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_warehouse:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
