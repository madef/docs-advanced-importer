 * severity:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * error_code:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * message:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * object_id:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_employee:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * object_type:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
