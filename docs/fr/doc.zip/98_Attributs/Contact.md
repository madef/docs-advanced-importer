 * email:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 128
 * customer_service:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * description:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: undefined
