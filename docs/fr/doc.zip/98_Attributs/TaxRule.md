 * id_tax_rules_group:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_country:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_state:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * zipcode_from:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * zipcode_to:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_tax:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * behavior:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * description:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
