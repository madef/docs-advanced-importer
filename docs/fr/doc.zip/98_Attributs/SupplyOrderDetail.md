 * id_supply_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_product_attribute:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * supplier_reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * ean13:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * upc:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * exchange_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * unit_price_te:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * quantity_expected:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * quantity_received:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * price_te:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * discount_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * discount_value_te:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * price_with_discount_te:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * tax_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * tax_value:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * price_ti:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * tax_value_with_order_discount:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * price_with_order_discount_te:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
