 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * location:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * ean13:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 13
 * upc:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 12
 * quantity:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 10
 * reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * supplier_reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * wholesale_price:
    * lang: false
    * shop: true
    * validator: none
    * required: false
    * size: 27
 * price:
    * lang: false
    * shop: true
    * validator: none
    * required: false
    * size: 20
 * ecotax:
    * lang: false
    * shop: true
    * validator: none
    * required: false
    * size: 20
 * weight:
    * lang: false
    * shop: true
    * validator: none
    * required: false
    * size: undefined
 * unit_price_impact:
    * lang: false
    * shop: true
    * validator: none
    * required: false
    * size: 20
 * minimal_quantity:
    * lang: false
    * shop: true
    * validator: none
    * required: true
    * size: undefined
 * default_on:
    * lang: false
    * shop: true
    * validator: none
    * required: false
    * size: undefined
 * available_date:
    * lang: false
    * shop: true
    * validator: none
    * required: false
    * size: undefined
