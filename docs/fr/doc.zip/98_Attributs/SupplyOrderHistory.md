 * id_supply_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_employee:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * employee_firstname:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * employee_lastname:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_state:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
