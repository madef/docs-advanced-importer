 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * description:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * short_description:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * meta_title:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 128
 * meta_description:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 255
 * meta_keywords:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: undefined
