 * id_reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * is_free:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * url:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_handling:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_external:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * range_behavior:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_method:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * max_width:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * max_height:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * max_depth:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * max_weight:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * grade:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 1
 * external_module_name:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * is_module:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * need_range:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * position:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * deleted:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * delay:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 128
