 * id_employee:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * employee_firstname:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * employee_lastname:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_stock:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * physical_quantity:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_stock_mvt_reason:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_supply_order:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * sign:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * last_wa:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * current_wa:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * price_te:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * referer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
