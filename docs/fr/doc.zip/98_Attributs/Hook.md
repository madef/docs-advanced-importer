 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * title:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * description:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * position:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * live_edit:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
