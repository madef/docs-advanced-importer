 * type:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 20
