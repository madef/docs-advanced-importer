 * secure_key:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * lastname:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * firstname:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * email:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 128
 * passwd:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * last_passwd_gen:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_gender:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * birthday:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * newsletter:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * newsletter_date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * ip_registration_newsletter:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * optin:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * website:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * company:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * siret:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * ape:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * outstanding_allow_amount:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * show_public_prices:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_risk:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * max_payment_days:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * deleted:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * note:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 65000
 * is_guest:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_shop_group:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_default_group:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_lang:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
