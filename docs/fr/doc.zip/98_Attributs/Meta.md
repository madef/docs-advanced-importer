i * page:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * configurable:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * title:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 128
 * description:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 255
 * keywords:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 255
 * url_rewrite:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: 255
