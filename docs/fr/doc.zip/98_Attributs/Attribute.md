 * id_attribute_group:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * color:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * position:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 128
