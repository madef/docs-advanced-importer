 * server:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * getvar:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined

