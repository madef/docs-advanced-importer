i * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * width:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * height:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * categories:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * products:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * manufacturers:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * suppliers:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * scenes:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * stores:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
