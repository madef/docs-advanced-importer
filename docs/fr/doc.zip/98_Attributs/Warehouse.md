 * id_address:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * reference:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 45
 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 45
 * id_employee:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * management_type:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * deleted:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
