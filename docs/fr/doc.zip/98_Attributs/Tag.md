 * id_lang:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
