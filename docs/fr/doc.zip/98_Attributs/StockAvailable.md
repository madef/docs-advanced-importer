 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_product_attribute:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_shop_group:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * quantity:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * depends_on_stock:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * out_of_stock:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
