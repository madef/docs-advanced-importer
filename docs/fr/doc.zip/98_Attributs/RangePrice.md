 * id_carrier:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
  delimiter1:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
  delimiter2:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
