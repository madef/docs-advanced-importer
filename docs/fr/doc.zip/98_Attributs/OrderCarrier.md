 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_carrier:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_order_invoice:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * weight:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_cost_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_cost_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * tracking_number:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
