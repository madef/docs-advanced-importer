 * id_parent:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * position:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * module:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * class_name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 64
