 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 200
 * sql:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
