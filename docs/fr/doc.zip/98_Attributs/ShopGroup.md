 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * share_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * share_order:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * share_stock:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * deleted:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined

