 * id_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * question:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * state:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
