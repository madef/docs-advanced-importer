 * order_reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 9
 * id_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * amount:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * payment_method:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * conversion_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * transaction_id:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 254
 * card_number:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 254
 * card_brand:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 254
 * card_expiration:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 254
 * card_holder:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 254
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
