 * is_color_group:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * group_type:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * position:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 128
 * public_name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 64
