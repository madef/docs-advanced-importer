 * id_operating_system:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_web_browser:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_customer:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * javascript:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * screen_resolution_x:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * screen_resolution_y:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * screen_color:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * sun_java:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * adobe_flash:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * adobe_director:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * apple_quicktime:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * real_player:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * windows_media:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * accept_language:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 8
 * mobile_theme:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
