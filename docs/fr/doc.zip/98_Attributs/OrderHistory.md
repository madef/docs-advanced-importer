 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_order_state:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_employee:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined

