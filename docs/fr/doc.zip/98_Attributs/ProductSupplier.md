 * product_supplier_reference:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 32
 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_product_attribute:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_supplier:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * product_supplier_price_te:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
