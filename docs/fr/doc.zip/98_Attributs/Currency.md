 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * iso_code:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 3
 * iso_code_num:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 3
 * blank:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * sign:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 8
 * format:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * decimals:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * conversion_rate:
    * lang: false
    * shop: true
    * validator: none
    * required: true
    * size: undefined
 * deleted:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
