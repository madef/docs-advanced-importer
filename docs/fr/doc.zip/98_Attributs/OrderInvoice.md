 * id_order:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * number:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * delivery_number:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * delivery_date:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_discount_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_discount_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_paid_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_paid_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_products:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_products_wt:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_shipping_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_shipping_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * shipping_tax_computation_method:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_wrapping_tax_excl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_wrapping_tax_incl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * note:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 65000
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined

