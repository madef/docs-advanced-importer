 * file:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 40
 * mime:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 128
 * file_name:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 128
 * file_size:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * description:
    * lang: true
    * shop: false
    * validator: none
    * required: false
    * size: undefined
