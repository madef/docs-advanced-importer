 * id_supplier:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * supplier_name:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * id_lang:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_warehouse:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_supply_order_state:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_ref_currency:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * reference:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * date_delivery_expected:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * total_te:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_with_discount_te:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_ti:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * total_tax:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * discount_rate:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * discount_value_te:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * is_template:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
