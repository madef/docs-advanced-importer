 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * main:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * domain:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 255
 * domain_ssl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 255
 * id_shop:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * physical_uri:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
 * virtual_uri:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 64
