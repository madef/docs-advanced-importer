 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * deleted:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 64
 * id_theme:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_category:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * id_shop_group:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
