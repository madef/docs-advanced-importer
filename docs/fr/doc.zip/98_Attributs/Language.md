 * name:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * iso_code:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 2
 * language_code:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 5
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * is_rtl:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_format_lite:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
 * date_format_full:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: 32
