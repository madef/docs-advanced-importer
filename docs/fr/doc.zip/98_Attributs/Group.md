 * reduction:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * price_display_method:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * show_prices:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_upd:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * name:
    * lang: true
    * shop: false
    * validator: none
    * required: true
    * size: 32
