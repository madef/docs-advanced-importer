 * id_product:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * display_filename:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 255
 * filename:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 255
 * date_add:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * date_expiration:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * nb_days_accessible:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 10
 * nb_downloadable:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: 10
 * active:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
 * is_shareable:
    * lang: false
    * shop: false
    * validator: none
    * required: false
    * size: undefined
