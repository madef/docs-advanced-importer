 * time_start:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
 * time_end:
    * lang: false
    * shop: false
    * validator: none
    * required: true
    * size: undefined
