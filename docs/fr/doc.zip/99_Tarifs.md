Le module est vendu au tarif de 150€ et inclus une assistance basique de 3 mois (activation du module, correction des bogues éventuels, …).

Pour des besoins plus spécifiques, comme de la configuration de modèle n'hésitez pas à demander un devis via addons avant l'achat du module.

Voici une liste des tarifs donnés à titre indicatif. Ces tarifs sont à ajouter au prix du module :
* réalisation d'un modèle pour un flux produit sans déclinaison : 150€
* réalisation d'un modèle pour un flux produit avec déclinaison : 200€
* réalisation d'un second modèle : 100€
* réalisation d'un modèle pour un flux commande : 350€
* développement d'un modifieur : 75€

Toutes ces prestations payantes sont effectées en général dans les 14 jours. Un delai plus court peut être garantis selon la situation et avec des tarifs 30% plus élevé en général.
